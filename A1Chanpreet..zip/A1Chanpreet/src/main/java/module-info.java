module com.example.a1chanpreet {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.a1chanpreet to javafx.fxml;
    exports com.example.a1chanpreet;
}