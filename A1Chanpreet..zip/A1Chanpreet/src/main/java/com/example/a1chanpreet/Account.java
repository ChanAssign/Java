// My name:Chanpreet
// Instructor name: Gursharan Tatla
// Date: 12 Oct, 2023
// Brief description of what the program is about: The following program is basically about the depositing and withdrawing the money from an account.

package com.example.a1chanpreet;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDateTime;


public class Account extends Application{

    // variables declaration
    private int id;

    private double balance;

    private LocalDateTime dateCreated;

    private Account [] accounts;

    // Default constructor which is having no parameters

    public Account(){

        balance = 100;
        dateCreated = LocalDateTime.now();
    }

    // Parameterized Constructor.
    public Account(int Id, double Balance ){

        id = Id;
        balance = Balance;
        dateCreated = LocalDateTime.now();
    }

    // getter methods to get the id and balance and date.
    public int getId(){
        return id;
    }

    public double getBalance(){
        return balance;
    }

    public LocalDateTime getDateCreated(){
        return dateCreated;
    }

    // method to deposit the money
    public void deposit(double depositAmount){

        balance = balance + depositAmount;
    }

    // method to withdraw the money.
    public void withdraw(double withdrawAmount){

        if(balance > withdrawAmount) {
            balance = balance - withdrawAmount;
        }
        else{
            System.out.println("You do not have enough amount to withdraw!");
        }
    }

    @Override
    public void start(Stage stage) throws IOException {

        showBalance(stage);
    }
    // method which I created to mainly show the balance and there are three button to perform this task.
        private void showBalance(Stage stage)
        {
            accounts = new Account[10];

            // setting the initial balance to 100 for all the ids using for loop.

            for( int i= 0; i< accounts.length; i++){
                accounts[i] = new Account(i, 100.00);
            }

            // Using different fields like label, text field and buttons

            Label lblId = new Label("ID");
            Label lblBalance = new Label("BALANCE");
            Label lblMessage = new Label();
            Label lblMsg = new Label();

            TextField txtId = new TextField();
            TextField txtBalance = new TextField();

            Button btnCheck = new Button("Check");
            Button btnDeposit = new Button("Deposit");
            Button btnWithdraw = new Button("Withdraw");

            // First button is displaying  the account id, balance and date after entering the id

            btnCheck.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {

                    int Id = Integer.parseInt(txtId.getText());

                    Account account = null;
                    for (Account data : accounts) {
                        if (data.getId() == Id) {
                            account = data;
                            break;
                        }
                    }

                    if (account != null) {
                        String Data = " Your Id is: " + account.getId()+ "\n Your Balance is: " + account.getBalance() + "$" + "\n Date Created: " + account.getDateCreated();
                        lblMessage.setText(Data);
                        lblMessage.setTextFill(Color.RED);
                        lblMessage.setFont(new Font("Arial", 16));
                    } else {
                        lblMessage.setText("Please enter the ID between 1 to 9..");
                        lblMessage.setTextFill(Color.GREEN);
                        lblMessage.setFont(new Font("Arial", 16));
                    }
                }
            });

            // Second button is deposit the money.

            btnDeposit.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {

                    int Id = Integer.parseInt(txtId.getText());
                    Double depositAmount= Double.parseDouble(txtBalance.getText());

                    Account account = null;
                    for (Account data : accounts) {
                        if (data.getId() == Id) {
                            account = data;
                            break;
                        }
                    }

                    if (account != null) {
                        account.deposit(depositAmount);

                        // Update the balance label
                        lblMsg.setText("Your Updated Balance is: " + account.getBalance()+ "$");
                        lblMsg.setTextFill(Color.RED);
                        lblMsg.setFont(new Font("Arial", 16));
                    }
                }
            });

            // Third button is used to withdraw the money.

            btnWithdraw.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                int Id = Integer.parseInt(txtId.getText());
                Double withdrawAmount = Double.parseDouble(txtBalance.getText());

                Account account = null;
                for (Account data : accounts) {
                    if (data.getId() == Id) {
                        account = data;
                        break;
                    }
                }

                if (account != null) {
                    if (withdrawAmount<= account.getBalance()) {
                        account.withdraw(withdrawAmount);

                        // Update the balance label
                        lblMsg.setText("Your Updated balance is: " + balance + "$");
                        lblMsg.setTextFill(Color.RED);
                        lblMsg.setFont(new Font("Arial", 16));
                    }
                    else {
                        lblMsg.setText("You do not have enough amount to withdraw!");
                        lblMsg.setTextFill(Color.GREEN);
                        lblMsg.setFont(new Font("Arial", 16));
                    }
                }
            }
        });

            GridPane root = new GridPane();
            root.addRow(0, lblId, txtId);
            root.addRow(2, btnCheck);
            root.addRow(3, lblMessage);
            root.addRow(4, lblBalance, txtBalance);
            root.addRow(5, btnDeposit);
            root.addRow(5, btnWithdraw);
            root.addRow(6, lblMsg);
            root.setHgap(20);
            root.setVgap(20);
            root.setPadding(new Insets(30,10,10,50));


            Scene scene = new Scene(root, 450, 500);
            stage.setTitle("Account Managing..");
            stage.setScene(scene);
            stage.show();
        }

    public static void main(String[] args) {
        launch();
    }
}

